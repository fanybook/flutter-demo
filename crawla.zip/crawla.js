const puppeteer = require('puppeteer');
const devices = require('puppeteer/DeviceDescriptors');
const cp = require('child_process');

cp.fork('./src/master.js');

// cp.exec('echo hello world', function(err, stdout) {
//   console.log(stdout);
// });

// let child = cp.fork('./child');
// child.on('message', function(msg) {
//   console.log('got a message is', msg);
// });
// child.send('hello world');

// let arr = [2, 3, 9 , 5, 6, 8];
// let brr = arr.slice(0);
// let crr = arr.concat();
// let idx = parseInt(Math.random() * arr.length);
// brr[2] = 567;
// crr[4] = 567;
// console.log(arr);
// console.log(brr);
// console.log(arr[idx]);
// // console.log(Math.random());
// // console.log(parseInt(Math.random() * arr.length));

// return false;


// (async () => {
//   const browser = await (puppeteer.launch({
//     // 若是手动下载的chromium需要指定chromium地址, 默认引用地址为 /项目目录/node_modules/puppeteer/.local-chromium/
//     executablePath: 'D:\\crawla\\chrome-win\\chrome.exe',
//     //设置超时时间
//     timeout: 15000,
//     //如果是访问https页面 此属性会忽略https错误
//     ignoreHTTPSErrors: true,
//     // 打开开发者工具, 当此值为true时, headless总为false
//     devtools: false,
//     // 关闭headless模式, 不会打开浏览器
//     headless: false
//   }));

//   let idx = parseInt(Math.random() * devices.length);
//   let device = devices[idx];
//   console.log("\n" + '设备列表：' + "\n");
//   console.log(device);

//   const page = await browser.newPage();
//   await page.emulate(device);
//   await page.setRequestInterception(true);
//   page.on('request', request => {
//     if (request.resourceType() == 'document' || request.resourceType() == 'xhr') {
//       request.continue();
//     } else {
//       request.abort();
//     }
//   });

//   page.on('requestfinished', request => {
//     if (request.resourceType() == 'xhr' && request.url().indexOf('product/detail') != -1) {
//       console.log("\n" + 'Api地址：' + "\n");
//       console.log(request.url());

//       (async () => {
//         let result = await request.response().json();
//         console.log("\n" + '各码价格：' + "\n");
//         console.log(result.data.sizeList);
//         console.log("\n" + '最近购买：' + "\n");
//         console.log(result.data.lastSoldList);

//         // 保存mysql和redis
//       })();
//     }
//   });

//   let product_id = 21770;
//   await page.goto('https://m.poizon.com/mdu/product/detail.html?id='+ product_id +'&source=shareDetail', {
//     waitUntil: 'networkidle2'
//   });
//   // await page.goto('https://m.poizon.com/mdu/product/detail.html?id=21771&source=shareDetail', {
//   //   waitUntil: 'networkidle2'
//   // });

//   // await page.screenshot({
//   //   path: product_id +'.png',
//   //   type: 'png',
//   //   fullPage: true,
//   // });

//   browser.close();
// })();
