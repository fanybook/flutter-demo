const cp = require('child_process');
const os = require('os');

// (async () => {
//   await testSync(1000);
// })();
// console.log(1);
while (true) {
  console.log(1);
  sleep(1000);
  // sleep2(1000);
  // setTimeout(function() {
  //   console.log(2);
  // }, 1000);
  // (async () => {
  //   await testSync(1000);
  // })();
}

// async function testSync(ms) {
//   const response = await new Promise((resolve) => {
//       setTimeout(() => {
//         resolve('async await test...'+ ms);
//       }, 1000);
//   });
//   console.log(response);
// }
// testSync(1000);
// console.log(1);

function sleep(ms) {
  for(var start = +new Date; +new Date - start <= ms; ) {
    // 阻塞循环 +new Date 等同于 new Date().getTime()
  }
}
// for(let i=0; i < os.cpus().length; i++){
//   cp.fork('./worker.js');
// }

// const fork = require('child_process').fork;
// const cpus = require('os').cpus();
// for(let i=0; i < cpus.length; i++){
//   fork('./worker.js');
// }
async function sleep2(ms) {
  await console.log('这是来自'+ ms +'ms之后的问好');
  await new Promise((resolve, reject) => {
    resolve('success');
    console.log('这是来自'+ ms +'ms之后的问好2');
    reject('error');
  });
  // setTimeout(function() {
  //   console.log('这是来自'+ ms +'ms之后的问好2');
  // }.bind(ms), ms);
}